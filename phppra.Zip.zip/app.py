from flask import Flask
import subprocess

app = Flask(__name__)

@app.route("/", methods=['GET'])
def index():
    result = subprocess.check_output(['php','./main.php'])
    return result

if __name__ == "__main__":
    app.run("localhost", 1000, debug=True)